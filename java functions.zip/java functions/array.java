public class ArrayStack<T> {
     private T[] stack;
     private int numElements = 0; // points to slot after top element

     public ArrayStack(T[] s) { stack = s; }  

     public boolean emptyStack() { 
         return numElements == 0; }
   
     public T  top() {
         return stack[numElements-1];
       }

     public void push(T x) {
         stack[numElements] = x;
         numElements++;
       }
  
     public T pop() {
         numElements--;
         return stack[numElements];
      }

    public static void main(String[] args) {
       ArrayStack<Integer> s = new ArrayStack<Integer>(new Integer[100]);
       s.push(2);
       s.push(3);
       s.push(5);
       System.out.println(s.top());
       System.out.println(s.pop());
       System.out.println(s.pop());
       s.push(15);
       s.push(22);
       System.out.println(s.pop());
   }
}
