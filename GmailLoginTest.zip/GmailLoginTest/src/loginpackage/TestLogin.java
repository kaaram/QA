package loginpackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TestLogin {
	public static void main(String [] args) throws InterruptedException
	{
		//open the browser
		
		System.setProperty("webdriver.chrome.driver", "/Users/aravindareddy/Desktop/Selenium -1/chromedriver");
		WebDriver d =new ChromeDriver();
		
		
		d.get("https://www.google.com/?gws_rd=ssl");

		d.findElement(By.id("gb_70")).click();
		
		d.findElement(By.id("Email")).sendKeys("aravindamotakatla@gmail.com");
		
		d.findElement(By.id("next")).click();
		Thread.sleep(5000);

		d.findElement(By.id("Passwd")).sendKeys("Aravinda793");

		d.findElement(By.id("signIn")).click();
		d.findElement(By.linkText("Gmail")).click();

		
	}

}
