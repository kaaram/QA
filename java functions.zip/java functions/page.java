public class LoginAuthAction extends ActionSupport {
    Private static final longserialVersionUID = 1L;
    private String userId;
    private String password;

    private Boolean error;

    public String execute() {
        if (userId.equals("")) {
            addActionError("Please Enter user id.");
            error = true;
        }
        else if(password.equals("")) {
            addActionError("Please Enter password.");
            error = true;
        }
        else if(!userId.equalsIgnoreCase(password)) {
            addActionError("Invalid userid or password.");
            error = true;
        } else {
            error = false;
        }

        if (error) {
            return ERROR;
        } else {
            return SUCCESS;
        }

    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPassword() {
        returnpassword;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}