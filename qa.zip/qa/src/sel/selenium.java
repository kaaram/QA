package sel;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class selenium {

	public static void main(String[] args) {
		
		class Account {
		    private double balance; 
		    Public Account(double initialDeposit) {
		       balance = initialDeposit; 
		    }
		    public synchronized double getBalance() {
		       return balance; 
		    }
		    public synchronized void deposit(double amount) {
		       balance += amont; 
		    }
		}

		
		public static void abs(int[] values) {
		    synchronized (values) {
		       for (int i = 0; i < values.length; i++) {
		          if (values[i] < 0)
		             values[i] = -values[i]; 
		       }
		    }
		}


	}

}
