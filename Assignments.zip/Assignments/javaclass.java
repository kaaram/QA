AppiumDriver driver;
@Before
public void testCaseSetup()throws Exception {
   //service.start();
   //reader.readFile();

   DesiredCapabilities cap = new DesiredCapabilities();
	
   cap.setCapability(MobileCapabilityType.PLATFORM_NAME,"Android");
   cap.setCapability(MobileCapabilityType.DEVICE_NAME, "Android device");
   cap.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, "4000");
   cap.setCapability(MobileCapabilityType.APP, "c://apk//sample.apk");
	
   driver = new AndroidDriver<MobileElement>("http://127.0.0.1:4444/wd/hub",cap);
}

@Test
public void testcase1()throws Exception {
   driver.findElementByID("Example").click();
   Asser.assertTrue(driver.findElementByID("Example").isDisplayed));
}

@After
public void testCaseTearDown() {
   driver.quit();
}